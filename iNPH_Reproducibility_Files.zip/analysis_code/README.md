# iNPH diagnostic and care-cascade meta-analysis

Reproducible R pipeline for the systematic review of diagnostic and treatment gaps in idiopathic normal-pressure hydrocephalus (iNPH).

Protocol registration: PROSPERO CRD420261458736.

## What this pipeline does

1. Imports the re-extraction workbook and validates every numerator/denominator.
2. Adds a small set of transparent derived effects that can be reconstructed from published flows.
3. Maps effects to prespecified, clinically coherent estimands.
4. Fits random-effects binomial-normal GLMMs for eligible single proportions.
5. Runs logit-REML/Hartung-Knapp, leave-one-out, overlap-swap and design-restriction sensitivity analyses.
6. Produces publication-ready forest plots, evidence maps, barrier, delay, facility, disparity and risk-of-bias figures.
7. Exports manuscript tables, model summaries, analysis decisions and a session-information audit trail.

The pipeline never pools facility surveys, administrative diagnosis rates or incompatible care stages with patient-level clinical cascades.

## Required software

- R 4.3 or newer recommended.
- RStudio is optional.
- Internet access is needed only for first-time package installation.

## Run

The simplest option is to open `iNPH_MetaAnalysis.Rproj`, open `START_HERE.R` and click **Source**.

The equivalent console commands are:

```r
source("run_all.R")
```

If packages are missing, first run:

```r
source("R/00_packages.R")
```

The included workbook is located at `data/raw/iNPH_Master_ReExtraction_v4.xlsx`. To use a later version, replace this file and update `config/analysis_config.yml`. Exact text matching is deliberately validated; if an estimand label changes, the pipeline stops and identifies the unmatched configuration row.

## Main outputs

- `results/tables/meta_summary.csv`: pooled estimates, heterogeneity and prediction intervals.
- `results/tables/analysis_manifest.csv`: every effect used in every analysis.
- `results/tables/unmapped_effects.csv`: extracted effects not assigned to a quantitative synthesis.
- `results/models/`: serialized model objects.
- `results/figures/`: PNG and 600-dpi TIFF figures.
- `results/logs/sessionInfo.txt`: software and package versions.

The final PRISMA accounting is stored in `config/prisma_fields.csv`: 1,680 records identified, 654 duplicates removed, 1,026 records screened, 73 full-text reports assessed and 39 reports retained. The only administrative check still flagged is confirmation that no sought report was unavailable.

## Prespecified quantitative hierarchy

- `P1_REFERRAL_TO_SHUNT`: shunt receipt from an initial suspected/referral cohort.
- `P2_DIAGNOSED_TO_SHUNT`: shunt receipt among diagnosed/probable iNPH.
- `S1_REFERRAL_TO_DIAGNOSIS`: diagnostic confirmation from the initial referral cohort.
- `S2_TEST_COMPLETION`: completion of a planned invasive/specialized work-up.
- `S3_TEST_POSITIVE_TO_SHUNT`: shunt receipt after a positive prognostic test.
- `S4_RECOMMENDATION_TO_SHUNT`: shunt receipt after referral/recommendation for surgery.
- `S5_POSTSHUNT_RESPONSE_6_12M`: broadly defined clinical response at approximately 6–12 months.

See `STATISTICAL_ANALYSIS_PLAN.md` for all definitions, sensitivity analyses and interpretation rules.

## Important interpretation rule

The complement of a completion proportion is **observed non-progression**, not automatically an avoidable gap. Barrier data are used to distinguish diagnostic reclassification, clinical non-eligibility, patient preference, waiting/system delay and loss to follow-up.

## Current feasibility

The strict mapping currently contains seven studies for each co-primary estimand and three to seven studies for each secondary stage. These counts permit random-effects synthesis but not reliable meta-regression or small-study-effect tests. The pipeline enforces these thresholds rather than silently running underpowered analyses.

## Final assessment status

- `config/risk_of_bias.csv` contains the author and structured ChatGPT-assisted second JBI judgments for all 20 studies contributing to a strict pooled analysis.
- `config/certainty_assessment.csv` contains the provisional GRADE-adapted judgments for all seven quantitative syntheses.
- `config/prisma_fields.csv` contains the closed search and screening counts using U=212.

Compare the risk-of-bias and certainty judgments with the review team's completed assessments before locking the manuscript. Then run `validate_inputs.py` and `source("run_all.R")` once to regenerate all tables and figures from the final configuration.
