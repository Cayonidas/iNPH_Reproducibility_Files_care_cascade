# Release v2.1 final configuration

Date: 2026-07-29

## Incorporated decisions

- PROSPERO: CRD420261458736.
- Updated-search unique records: U=212.
- PRISMA totals: 1,680 records identified; 654 duplicates removed; 1,026 screened; 953 excluded at title/abstract; 73 full-text reports assessed; 34 full-text reports excluded; 39 reports retained.
- Author and structured ChatGPT-assisted second risk-of-bias judgments completed for the 20 strict pooled study units using adapted JBI prevalence/proportion domains.
- ROBINS-I judgments completed for the three eligible nonrandomized within-study comparisons.
- Provisional GRADE-adapted certainty judgments completed for all seven quantitative syntheses.

## Figure changes

- Removed repeated captions from individual panels in the four-stage forest-plot composite.
- Increased horizontal plotting space for comparative estimates and confidence-interval text.
- Increased Figure 6 width.
- Rebuilt the risk-of-bias plot with readable author-year labels, ordered domains and a larger export canvas.

## Validation

`validate_inputs.py` completed with:

- 0 unmatched mapped effects;
- 0 duplicated map rows;
- 0 unknown study identifiers;
- 0 R delimiter smoke-test errors.

Run `START_HERE.R` once in RStudio to regenerate the complete result set and the final risk-of-bias figure.
