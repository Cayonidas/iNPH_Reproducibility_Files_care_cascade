# Como executar no RStudio

## Caminho mais simples

1. Descompacte todo o arquivo ZIP, preservando a estrutura de pastas.
2. Abra o arquivo `iNPH_MetaAnalysis.Rproj` no RStudio.
3. Abra `START_HERE.R`.
4. Clique em **Source**.

O script instalará os pacotes ausentes e executará:

- validação de numeradores, denominadores, efeitos e sobreposições;
- GLMMs dos estimandos primários e secundários;
- modelo de sensibilidade REML/Hartung–Knapp;
- cenários de sensibilidade e leave-one-out;
- comparações de implementação e atraso;
- tabelas CSV e Excel;
- figuras PNG e TIFF em resolução de publicação;
- registro das versões do R e dos pacotes.

## Comandos equivalentes

Se preferir usar o console:

```r
source("R/00_packages.R")
source("run_all.R")
```

## O que deve aparecer ao final

```text
results/
├── figures/
├── logs/
├── models/
└── tables/
```

O arquivo principal de resultados numéricos será:

```text
results/tables/iNPH_Analysis_Results.xlsx
```

Os resultados combinados estarão também em:

```text
results/tables/meta_summary.csv
results/tables/manuscript_meta.csv
results/tables/sensitivity_grid.csv
results/tables/leave_one_out.csv
```

## O que me enviar depois da execução

Compacte e envie a pasta inteira `results`. Ela conterá:

- estimativas combinadas e intervalos de predição;
- heterogeneidade;
- sensibilidades;
- figuras;
- modelos salvos;
- `sessionInfo.txt`;
- logs de erro ou de análises não executadas.

Se a execução parar com erro, não altere o código inicialmente. Envie:

1. a mensagem completa do console;
2. `results/logs`, se a pasta tiver sido criada;
3. a versão do R exibida por `R.version.string`.

## Atualização com novos artigos

Os novos textos completos devem ser incorporados primeiro à planilha mestra e ao `config/effect_map.csv`. Depois, basta executar `START_HERE.R` novamente. O pipeline recalculará todas as tabelas e figuras sem necessidade de editar manualmente cada análise.
