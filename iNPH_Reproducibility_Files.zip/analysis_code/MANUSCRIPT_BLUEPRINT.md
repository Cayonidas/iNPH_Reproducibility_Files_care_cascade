# Blueprint do manuscrito

## Título provisório

**From suspicion to shunt: diagnostic and care-cascade gaps in idiopathic normal-pressure hydrocephalus — a systematic review and meta-analysis**

Alternativa mais clínica:

**Where patients are lost in the idiopathic normal-pressure hydrocephalus care pathway: a systematic review and meta-analysis of recognition, evaluation, treatment and delay**

## Contribuição central

O artigo deve responder **onde e por que ocorre não progressão**, e não apresentar uma única proporção chamada genericamente de “diagnostic gap”. A principal inovação é organizar a evidência em uma cascata explícita:

1. população ou grupo de risco;
2. suspeita/referência clínica;
3. investigação especializada;
4. diagnóstico provável/definido;
5. recomendação ou elegibilidade cirúrgica;
6. derivação;
7. resposta após derivação.

A não progressão observada será decomposta em:

- reclassificação diagnóstica ou diagnóstico alternativo;
- não conclusão da investigação;
- contraindicação ou benefício esperado insuficiente;
- decisão do paciente/família;
- espera, capacidade ou falha de implementação;
- perda de seguimento;
- seleção/atrito de pesquisa.

Essa distinção impede que seleção clínica apropriada seja rotulada como falha assistencial evitável.

## Anterioridade e posicionamento

As revisões identificadas concentram-se em outros objetos:

- desfecho após shunt e complicações: Toma et al. (2013), PMID 23975646;
- modalidades cirúrgicas e complicações: Giordan et al. (2019), PMID 30497150;
- epidemiologia/prevalência/incidência: Martín-Láez et al. (2015), PMID 26183137, e Zaccaria et al. (2020), PMID 31622497;
- preditores clínicos ou radiológicos de resposta: Thavarajasingam et al. (2021/2023), PMID 36435931 para a revisão radiológica;
- acurácia de drenagem lombar externa: Nunn et al. (2021), DOI 10.1080/02688697.2020.1787948;
- revisão abrangente antiga de diagnóstico e desfecho: Hebb e Cusimano (2001), PMID 11846911.

Até a atualização conduzida para este projeto, não foi identificada revisão sistemática com meta-análise que quantifique toda a sequência reconhecimento → investigação → decisão → shunt, mantendo denominadores por estágio e integrando motivos de não progressão, atrasos, capacidade institucional e disparidades. No texto final, usar formulação prudente: **“To our knowledge, this is the first systematic review to…”**, seguida da data final da busca. A afirmação deverá ser novamente verificada imediatamente antes da submissão.

## Objetivos

### Objetivos primários

1. Estimar a proporção de pacientes derivados entre aqueles que entram no cuidado como suspeitos/referidos por iNPH.
2. Estimar a proporção de pacientes derivados entre aqueles classificados como iNPH provável/diagnosticada.

### Objetivos secundários

1. Estimar conclusão diagnóstica, conclusão de testes, operação após teste positivo e operação após recomendação.
2. Descrever os motivos de não progressão por estágio e por denominador.
3. Avaliar associações entre organização do cuidado/atraso e conclusão, tratamento ou resposta.
4. Mapear capacidade institucional e práticas de referência.
5. Sintetizar sinais de desigualdade no reconhecimento, diagnóstico ou tratamento.
6. Apresentar resposta pós-shunt apenas como contexto do benefício potencial perdido, não como estimativa do gap.

## Viabilidade quantitativa atual

| Estimando estrito | k | Eventos | Soma dos denominadores | Decisão |
|---|---:|---:|---:|---|
| Suspeita/referência → shunt | 7 | 706 | 1.646 | Meta-análise principal |
| Diagnóstico/provável iNPH → shunt | 7 | 644 | 837 | Meta-análise principal |
| Suspeita/referência → diagnóstico | 6 | 660 | 1.251 | Meta-análise secundária |
| Teste planejado/tentado → concluído | 7 | 474 | 522 | Meta-análise secundária |
| Teste prognóstico positivo → shunt | 5 | 282 | 312 | Meta-análise secundária |
| Recomendação/referência cirúrgica → shunt | 3 | 216 | 248 | Exploratória; limiar mínimo |
| Shunt → resposta em aproximadamente 6–12 meses | 5 | 256 | 318 | Contexto de benefício |

As somas acima são apenas descrições de viabilidade. Não são estimativas combinadas e não corrigem heterogeneidade.

## Ordem analítica

### Tier 1 — achado principal

- P1: suspeita/referência → shunt;
- P2: diagnóstico/provável iNPH → shunt;
- modelo binomial-normal de efeitos aleatórios com link logit;
- proporção combinada, IC95%, intervalo de predição, tau², I² e Q;
- complemento descrito como “observed non-progression”.

### Tier 2 — localização da perda na cascata

- suspeita/referência → diagnóstico;
- teste planejado/tentado → conclusão;
- teste positivo → shunt;
- recomendação → shunt;
- resposta em 6–12 meses.

### Tier 3 — explicação e possibilidade de intervenção

- motivos/barreiras com denominador explícito;
- comparações antes/depois de protocolo;
- comparações de tratamento precoce versus tardio;
- atrasos por intervalo assistencial;
- avaliação de espera e deterioração durante a espera.

### Tier 4 — contexto do sistema

- capacidade e práticas de instituições;
- uso de diretrizes, DESH, testes e colaboração multidisciplinar;
- taxas administrativas de diagnóstico/procedimento;
- sexo, raça/etnia, renda, região e outros sinais de desigualdade.

## Estratégia estatística

### Proporções únicas

- primária: GLMM binomial-normal, logit, máxima verossimilhança;
- IC de cada estudo: Clopper–Pearson exato;
- sensibilidade: logit, variância inversa, REML e Hartung–Knapp;
- sem correção de continuidade rotineira no modelo primário;
- sem modelo de efeito fixo como conclusão principal.

### Heterogeneidade

- interpretar o intervalo de predição antes de generalizar a média combinada;
- não multiplicar proporções combinadas de estágios provenientes de coortes diferentes;
- subgrupos somente com pelo menos três estudos por nível;
- meta-regressão univariável somente com pelo menos dez estudos independentes;
- meta-regressão multivariável somente com pelo menos vinte estudos e número de parâmetros justificável.

### Comparações

- RR para desfechos binários dentro do mesmo estudo;
- diferença de médias para atrasos com mesmo ponto inicial/final e média/DP disponíveis;
- não combinar desfechos conceitualmente diferentes;
- comparações não randomizadas serão interpretadas como associações contextuais.

### Atrasos

- classificar o ponto inicial e final antes de analisar;
- converter a unidade para meses apenas para visualização;
- não converter mediana em média no modelo principal;
- não combinar “duração dos sintomas” com “tempo de espera do sistema”.

### Sobreposição

- um relatório por coorte e estimando no modelo principal;
- troca Pyykkö/Junkkari e Kuriyama/Nakajima em sensibilidades prespecificadas;
- exclusão de cluster completo em análise de influência quando necessário.

### Risco de viés e certeza

- ferramenta JBI adequada a cada desenho, sem escore somado;
- QUADAS-3 apenas para pergunta genuína de acurácia diagnóstica;
- julgamentos por domínio com consenso entre dois avaliadores;
- certeza por estimando principal considerando risco de viés, inconsistência, indireção, imprecisão e viés de publicação.

## Plano de tabelas

### Artigo principal

1. **Tabela 1 — Características dos estudos e ponto de entrada na cascata.**
2. **Tabela 2 — Estimativas combinadas por estágio.** Inclui k, N, proporção, IC95%, intervalo de predição e heterogeneidade.
3. **Tabela 3 — Motivos de não progressão e implicação potencial.** Cada linha mantém estágio, n/N e classificação clínica/sistema/paciente.

### Suplemento

- estratégia completa de busca por base;
- decisões de texto completo;
- efeitos individuais e definições exatas;
- matriz de coortes sobrepostas;
- todas as sensibilidades;
- comparações de implementação/atraso;
- capacidade institucional;
- disparidades;
- risco de viés e certeza.

## Plano de figuras

### Artigo principal

1. **PRISMA 2020.** Gerar somente após fechamento da triagem.
2. **Mapa da cascata e densidade da evidência.** Número de estudos por estágio, sem construir uma cascata sintética por multiplicação.
3. **Forest plots dos dois estimandos coprimários.**
4. **Forest plots dos estágios intermediários prioritários.**
5. **Motivos de não progressão por categoria e estágio.** Sem diamante quando os denominadores não forem comparáveis.
6. **Implementação e atraso.** Comparações de protocolo/tempo e síntese estruturada dos intervalos.

### Suplemento

- todos os efeitos individuais;
- resposta pós-shunt;
- análises de influência e troca de coorte;
- evidência de instalações;
- disparidades;
- risco de viés;
- funnel plot apenas se k ≥ 10 em um estimando clinicamente coerente.

## Estrutura dos resultados

1. seleção dos estudos;
2. características e pontos de entrada;
3. estimandos coprimários;
4. estágios intermediários;
5. motivos de não progressão;
6. atrasos e organização do cuidado;
7. capacidade institucional e disparidades;
8. risco de viés, certeza e sensibilidades.

## Estrutura da discussão

1. **Achado central:** não existe um único gap universal; a magnitude depende do ponto de entrada e do sistema.
2. **Onde ocorre a perda:** separar diagnóstico, elegibilidade, preferência e implementação.
3. **O que parece modificável:** protocolos, coordenação multidisciplinar, tempo de espera e capacidade local.
4. **O que não deve ser chamado de falha:** reclassificação diagnóstica e contraindicação clinicamente justificada.
5. **Equidade:** taxas administrativas diferentes são sinais de acesso/ascertainment, não prova de diferença biológica.
6. **Implicações:** conjunto mínimo padronizado de métricas para futuras clínicas e registros de iNPH.
7. **Limitações:** heterogeneidade de critérios, seleção por teste, sobreposição, poucos estudos por estágio, definições de atraso e desfecho.

## Produto adicional que agrega conhecimento

Propor um **iNPH Care-Cascade Reporting Core Set** para estudos futuros:

- N inicialmente suspeito/referido;
- N que conclui avaliação especializada;
- N classificado como provável/definido;
- N submetido a cada teste e N com teste positivo;
- N recomendado/referido para cirurgia;
- N operado;
- razões mutuamente documentadas para não progressão;
- tempo entre cada par de estágios;
- resposta e perdas de seguimento em tempo definido;
- idade, sexo/gênero, raça/etnia quando permitido, nível socioeconômico, geografia e distância;
- disponibilidade institucional e desenho do pathway.

Esse core set pode ser apresentado como box ou tabela final e provavelmente será uma das partes mais citáveis do artigo.

## Referências metodológicas de trabalho

- PRISMA 2020: https://www.prisma-statement.org/prisma-2020
- SWiM: https://www.bmj.com/content/368/bmj.l6890
- Cochrane Handbook, capítulo 10: https://www.cochrane.org/authors/handbooks-and-manuals/handbook/current/chapter-10
- `metafor::rma.glmm`: https://wviechtb.github.io/metafor/reference/rma.glmm.html
- JBI critical appraisal tools: https://jbi.global/critical-appraisal-tools

