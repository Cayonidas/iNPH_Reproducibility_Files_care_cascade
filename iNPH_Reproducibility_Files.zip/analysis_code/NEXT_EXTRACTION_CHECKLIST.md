# Checklist para os próximos textos completos

Cada novo artigo deve ser extraído no nível do **efeito**, não apenas no nível do estudo. Uma mesma publicação pode fornecer vários estágios, desde que cada numerador permaneça ligado ao denominador correto.

## 1. Identificação e independência

- Study ID padronizado;
- país, centro, período de recrutamento e desenho;
- registro/base de dados;
- população de entrada e critérios de inclusão;
- relação com publicações já incluídas;
- coorte sobreposta: sim/não/incerto;
- relatório preferido para cada estimando e motivo.

## 2. Transições prioritárias

Para cada transição, registrar `n`, `N`, definição, estágio, tempo e fonte exata:

- suspeita/referência → avaliação concluída;
- suspeita/referência → diagnóstico provável/definido;
- teste planejado/tentado → teste concluído;
- teste concluído → teste positivo;
- diagnóstico/provável → recomendação cirúrgica;
- teste positivo → recomendação;
- teste positivo → shunt;
- recomendação/referência cirúrgica → shunt;
- suspeita/referência → shunt;
- shunt → resposta em tempo definido.

## 3. Motivos de não progressão

Extrair contagem e denominador para cada motivo:

- diagnóstico alternativo ou critérios insuficientes;
- teste recusado, tecnicamente impossível, interrompido ou não agendado;
- contraindicação médica/cirúrgica;
- benefício esperado insuficiente;
- recusa/preferência do paciente ou família;
- espera, fila, capacidade, transferência ou falta de especialista;
- perda de seguimento/não comparecimento;
- morte antes do tratamento;
- paciente ainda em investigação/aguardando no fechamento;
- exclusão de pesquisa que não equivale a perda assistencial.

Não usar categorias sobrepostas como se fossem mutuamente exclusivas. Registrar se a soma pode ou não igualar o total não tratado.

## 4. Atrasos

- ponto inicial e final exatos;
- média/DP/n ou mediana/IQR/n;
- unidade;
- grupo comparador;
- atraso de sintomas versus atraso do sistema;
- deterioração durante a espera;
- ajuste estatístico e covariáveis.

## 5. Implementação e sistema

- pathway padronizado/multidisciplinar;
- era pré/pós-protocolo;
- acesso a MRI, tap test, ELD, infusion test, neuropsicologia e cirurgia;
- encaminhamento externo;
- volume institucional;
- uso de diretrizes;
- capacidade de acompanhamento pós-operatório.

## 6. Equidade

- idade;
- sexo/gênero;
- raça/etnia;
- renda/seguro/privação;
- ruralidade, região, distância;
- odds ratio/risco/taxa ajustada e IC95%;
- nível da variável: individual, área ou instituição;
- distinção entre incidência biológica, diagnóstico codificado e utilização.

## 7. Desfechos pós-shunt

- definição de resposta;
- domínio: marcha, cognição, continência, escala global;
- tempo exato;
- denominador de operados ou apenas seguidos;
- perdas de seguimento;
- cegamento do avaliador, se aplicável.

## 8. Risco de viés

- amostragem/consecutividade;
- validade da definição de suspeita e diagnóstico;
- mensuração do desfecho;
- completude do seguimento;
- seleção para teste ou cirurgia;
- confusão em comparações;
- reporte incompleto dos fluxos.

## 9. Regra de decisão para inclusão quantitativa

O artigo entra em uma meta-análise apenas quando fornecer:

1. numerador e denominador reconstruíveis;
2. unidade de análise identificável;
3. ponto de entrada compatível com um estimando;
4. independência ou cluster de sobreposição resolvido;
5. definição de desfecho suficientemente comparável.

Caso contrário, ele ainda pode contribuir para barreiras, atrasos, implementação, capacidade, disparidades ou discussão, mas não receberá um diamante combinado.

