# Validation report

Validation date: 22 July 2026

## Input integrity

- master transition effects: 140;
- transparent derived effects: 5;
- analysis-map rows: 59;
- unique mapped source effects: 57;
- unmatched mapped effects: 0;
- duplicated map rows within an analysis/set: 0;
- unknown study IDs: 0;
- R delimiter smoke-test errors: 0.

The master workbook was also imported through an independent spreadsheet reader and the six analysis-critical tabs were visually/structurally inspected: `Study_Master`, `Transitions`, `Barriers`, `Delays`, `Facility_Survey` and `Disparities`.

## Strict-set feasibility

| Analysis | k | Events | Sum of denominators |
|---|---:|---:|---:|
| P1_REFERRAL_TO_SHUNT | 7 | 706 | 1,646 |
| P2_DIAGNOSED_TO_SHUNT | 7 | 644 | 837 |
| S1_REFERRAL_TO_DIAGNOSIS | 6 | 660 | 1,251 |
| S2_TEST_COMPLETION | 7 | 474 | 522 |
| S3_TEST_POSITIVE_TO_SHUNT | 5 | 282 | 312 |
| S4_RECOMMENDATION_TO_SHUNT | 3 | 216 | 248 |
| S5_POSTSHUNT_RESPONSE_6_12M | 5 | 256 | 318 |

These sums are descriptive checks only and are not pooled estimates.

## Runtime status

The current execution container does not include R, so the numerical GLMM fits and publication figures were not executed here. The source/config linkage, counts, identifiers, denominators, required files and delimiter balance were validated. The pipeline is designed to stop with an explicit log on unmatched effects, invalid counts, duplicated studies or duplicated overlap clusters when run in R 4.3+.

The definitive numerical validation step is:

```r
source("R/00_packages.R")
source("run_all.R")
```

The resulting `sessionInfo.txt`, model objects, CSV tables and figures should be archived with the submitted article.
